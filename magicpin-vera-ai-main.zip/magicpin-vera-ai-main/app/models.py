from pydantic import BaseModel
from typing import Any, List, Optional


class ContextRequest(BaseModel):
    scope: str
    context_id: str
    version: int
    payload: Any
    delivered_at: str


class TickRequest(BaseModel):
    now: str
    available_triggers: List[str]


class ReplyRequest(BaseModel):
    conversation_id: str
    merchant_id: str
    customer_id: Optional[str] = None
    from_role: str
    message: str
    received_at: str
    turn_number: int


class Action(BaseModel):
    action: str
    body: str
    cta: str
    rationale: str