merchant_contexts = {}
customer_contexts = {}
category_contexts = {}
trigger_contexts = {}
conversation_history = {}


def save_context(scope, context_id, payload):
    if scope == "merchant":
        merchant_contexts[context_id] = payload

    elif scope == "customer":
        customer_contexts[context_id] = payload

    elif scope == "category":
        category_contexts[context_id] = payload

    elif scope == "trigger":
        trigger_contexts[context_id] = payload


def get_context(scope, context_id):
    if scope == "merchant":
        return merchant_contexts.get(context_id)

    if scope == "customer":
        return customer_contexts.get(context_id)

    if scope == "category":
        return category_contexts.get(context_id)

    if scope == "trigger":
        return trigger_contexts.get(context_id)

    return None


def add_message(conversation_id, role, message):
    if conversation_id not in conversation_history:
        conversation_history[conversation_id] = []

    conversation_history[conversation_id].append(
        {
            "role": role,
            "message": message
        }
    )


def get_history(conversation_id):
    return conversation_history.get(conversation_id, [])


def reset_storage():
    merchant_contexts.clear()
    customer_contexts.clear()
    category_contexts.clear()
    trigger_contexts.clear()
    conversation_history.clear()