import json
from pathlib import Path

from app.storage import save_context

BASE = Path(__file__).resolve().parent.parent
DATASET = BASE / "dataset"


def load_json(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_seed_data():
    merchants = load_json(DATASET / "merchants_seed.json")

    for merchant in merchants["merchants"]:
        save_context(
            "merchant",
            merchant["merchant_id"],
            merchant
        )

    customers = load_json(DATASET / "customers_seed.json")

    for customer in customers["customers"]:
        save_context(
            "customer",
            customer["customer_id"],
            customer
        )

    triggers = load_json(DATASET / "triggers_seed.json")

    for trigger in triggers["triggers"]:
        save_context(
            "trigger",
            trigger["id"],
            trigger
        )

    category_folder = DATASET / "categories"

    for file in category_folder.glob("*.json"):
        category = load_json(file)

        save_context(
            "category",
            file.stem,
            category
        )

    print("Dataset Loaded Successfully")