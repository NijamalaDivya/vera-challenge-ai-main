from fastapi import APIRouter

from app.models import (
    ContextRequest,
    TickRequest,
    ReplyRequest,
)

from app.storage import (
    save_context,
    get_context,
    add_message,
    reset_storage,
)

from app.loader import load_seed_data

from app.composer import generate_message

router = APIRouter()


@router.get("/v1/healthz")
def healthz():
    return {
        "status": "ok"
    }


@router.get("/v1/metadata")
def metadata():
    return {
        "name": "Magicpin Vera AI",
        "version": "1.0.0",
        "author": "Revanth",
        "description": "Merchant Engagement Backend"
    }


@router.post("/v1/context")
def context(request: ContextRequest):

    save_context(
        request.scope,
        request.context_id,
        request.payload
    )

    return {
        "status": "stored"
    }


@router.post("/v1/tick")
def tick(request: TickRequest):

    actions = []

    for trigger_id in request.available_triggers:

        trigger = get_context("trigger", trigger_id)

        if trigger is None:
            continue

        action = generate_message(
            merchant_id=trigger.get("merchant_id"),
            customer_id=trigger.get("customer_id"),
            trigger=trigger
        )

        actions.append(action)

    return {
        "actions": actions
    }


@router.post("/v1/reply")
def reply(request: ReplyRequest):

    add_message(
        request.conversation_id,
        request.from_role,
        request.message
    )

    response = generate_message(
        merchant_id=request.merchant_id,
        customer_id=request.customer_id,
        conversation_id=request.conversation_id,
        user_message=request.message
    )

    add_message(
        request.conversation_id,
        "assistant",
        response
    )

    return {
        "reply": response
    }


@router.post("/v1/reset")
def reset():

    reset_storage()

    load_seed_data()

    return {
        "status": "reset"
    }