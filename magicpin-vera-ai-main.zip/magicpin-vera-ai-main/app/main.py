from fastapi import FastAPI

from app.routes import router
from app.loader import load_seed_data

app = FastAPI(
    title="Magicpin Vera AI",
    version="1.0.0"
)


@app.on_event("startup")
def startup():

    load_seed_data()


app.include_router(router)