from app.storage import (
    get_context,
    get_history
)


def merchant_name(merchant):
    if not merchant:
        return "our store"

    identity = merchant.get("identity", {})
    return identity.get("name", "our store")


def merchant_category(merchant):
    if not merchant:
        return ""

    return merchant.get("category_slug", "")


def merchant_offers(merchant):
    if not merchant:
        return []

    return merchant.get("offers", [])


def review_themes(merchant):
    if not merchant:
        return []

    return merchant.get("review_themes", [])


def build_offer_text(merchant):

    offers = merchant_offers(merchant)

    if not offers:
        return ""

    texts = []

    for offer in offers:

        title = offer.get("title")

        if title:
            texts.append(title)

    if len(texts) == 0:
        return ""

    if len(texts) == 1:
        return texts[0]

    return ", ".join(texts)


def build_review_summary(merchant):

    reviews = review_themes(merchant)

    if not reviews:
        return ""

    result = []

    for review in reviews[:3]:

        theme = review.get("theme")

        if theme:
            result.append(theme)

    return ", ".join(result)


def build_merchant_prompt(merchant):

    name = merchant_name(merchant)

    category = merchant_category(merchant)

    offers = build_offer_text(merchant)

    reviews = build_review_summary(merchant)

    text = f"{name}"

    if category:
        text += f" is a {category} business."

    if offers:
        text += f" Current offers include {offers}."

    if reviews:
        text += f" Customers frequently mention {reviews}."

    return text


def customer_name(customer):

    if not customer:
        return "Customer"

    identity = customer.get("identity", {})

    return identity.get("name", "Customer")


def customer_preferences(customer):

    if not customer:
        return {}

    return customer.get("preferences", {})


def relationship(customer):

    if not customer:
        return ""

    rel = customer.get("relationship", {})

    return rel.get("status", "")
def generate_tick_action(trigger):

    kind = trigger.get("kind", "").lower()

    merchant_id = trigger.get("merchant_id")
    customer_id = trigger.get("customer_id")

    merchant = get_context("merchant", merchant_id)
    customer = get_context("customer", customer_id)

    store = merchant_name(merchant)
    customer_name_text = customer_name(customer)

    body = ""
    cta = ""
    rationale = ""

    if kind == "inactive_customer":
        body = (
            f"Hi {customer_name_text}, we've missed you at {store}! "
            "Visit us again and enjoy our latest offers."
        )
        cta = "Visit Now"
        rationale = "Re-engage an inactive customer."

    elif kind == "new_offer":
        body = (
            f"{store} has launched exciting new offers. "
            "Come and check them out today!"
        )
        cta = "View Offer"
        rationale = "Notify customers about new promotions."

    elif kind == "birthday":
        body = (
            f"Happy Birthday, {customer_name_text}! "
            f"Celebrate with a special surprise from {store}."
        )
        cta = "Claim Gift"
        rationale = "Birthday engagement."

    elif kind == "feedback_request":
        body = (
            f"Thanks for visiting {store}. "
            "We'd love to hear your feedback."
        )
        cta = "Give Feedback"
        rationale = "Collect customer feedback."

    else:
        body = (
            f"Hello {customer_name_text}, "
            f"don't miss what's new at {store}!"
        )
        cta = "Explore"
        rationale = "General engagement."

    return {
        "action": "send_message",
        "body": body,
        "cta": cta,
        "rationale": rationale,
    }


def generate_reply(conversation_id, merchant_id, user_message):

    merchant = get_context("merchant", merchant_id)

    history = get_history(conversation_id)

    store = merchant_name(merchant)
    category = merchant_category(merchant)
    offers = build_offer_text(merchant)

    message = user_message.lower()

    if "offer" in message or "discount" in message:
        if offers:
            return (
                f"At {store}, we currently have "
                f"{offers}. We'd love to see you!"
            )

        return (
            f"{store} keeps introducing exciting offers. "
            "Please visit us to know more."
        )

    if "time" in message or "open" in message:
        return (
            f"Please check the latest opening hours of "
            f"{store} on the Magicpin app."
        )

    if "location" in message or "address" in message:
        return (
            f"You can find the exact location of "
            f"{store} inside the Magicpin app."
        )

    if "thank" in message:
        return (
            "You're welcome! Looking forward to serving you again."
        )

    if len(history) > 5:
        return (
            f"Thanks for staying connected with {store}. "
            "How else may we help you today?"
        )

    if category:
        return (
            f"Welcome to {store}, your trusted "
            f"{category} partner. "
            "How may we assist you today?"
        )

    return (
        f"Hello! Welcome to {store}. "
        "How can we help you today?"
    )


def generate_message(
    merchant_id,
    customer_id=None,
    trigger=None,
    conversation_id=None,
    user_message=None,
):

    if trigger is not None:
        return generate_tick_action(trigger)

    return generate_reply(
        conversation_id,
        merchant_id,
        user_message,
    )